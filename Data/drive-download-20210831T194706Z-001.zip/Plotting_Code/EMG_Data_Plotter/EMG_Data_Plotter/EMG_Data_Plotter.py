import os
import numpy as np
import statistics
import matplotlib.pyplot as plt
##################################S SETUP #####################################

path = "D:/4thYear/ADAPT/Data/Bicep_Tests/060421/"
filename = "6_4_21-Test5.txt"
path = os.path.join(path,filename)
print(path)

time=[]
bicep=[]
tricep=[]

with open(path, 'r') as file:
  for ith_row, row in enumerate(file): #iterates through each row of file
    for jth_col, value in enumerate(row.split(",")): # iterate throuch each column in row. splitting results by the comma
      if jth_col ==0:
        time.append(float(value))              #converted into float
      elif jth_col ==1: 
        bicep.append(int(value))               #converted into integers
      else:
        tricep.append(int(value))              #converted into integers

#a=max(bicep)
#print(a)
#tricep=np.multiply(tricep, 1023/a)    #   Scaling the tricep to be equal with the bicep

std_time = []
std_bicep = []
std_tricep = []

window_range = 100
temp_y = []

for i in range(len(bicep)):
    temp_y.append(float(bicep[i]))
    if ((i+1)%window_range == 0):
        std_bicep.append(statistics.stdev(temp_y))
        std_time.append(time[int(i - window_range/2)])
        temp_y = []


plt.figure()
plt.plot(time,bicep, label = "Bicep")
plt.plot(time,tricep, label = "Tricep")
plt.plot(std_time, std_bicep, label = "Bicep Deviation")
plt.xlabel("Time (s)")
plt.ylabel("Sensor Reading")
plt.title("Reading vs. Time")
plt.show()









sec = input("Press 'Enter' to continue...")
#np.savetxt("Time_data6",time)
#np.savetxt("Bicep_data6",bicep)
#np.savetxt("Tricep_data6",tricep)